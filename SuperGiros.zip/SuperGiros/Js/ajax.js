/* 
 * Código JaVaScript uso de Ajax
 * 
 * @Autor César Marino Cuéllar
 */
$(function(){     
      
  $("#button").button();
    //#departamento: el campo select de los departamentos
    $("#txtIdentificacionRemitente").change(function(){  
    var parametros = {
        "identificacion" : $('#txtIdentificacionRemitente').val(),
        "opcion":2
    };    
  
    $.ajax({      
            url:   '../Controlador/ctrlGiro.php',
            data:  parametros,
            type:  'post',                
            success:  function (response) {               
                if(response != ""){
                    $("#MensajeRemitente").html(response);
               }else{
                    $("#MensajeRemitente").html("No Existe Persona debe primero Agregarla");
                }
            }       
        });        
    });
    
    $("#txtIdentificacionDestinatario").change(function(){ 
    
    var parametros = {
        "identificacion" : $('#txtIdentificacionDestinatario').val(),
        "opcion":2
    };   
  
    $.ajax({      
            url:   '../Controlador/ctrlGiro.php',
            data:  parametros,
            type:  'post',                
            success:  function (response) {  
               if(response != ""){
                    $("#MensajeDestinatario").html(response);
               }else{
                    $("#MensajeDestinatario").html("No Existe Persona debe primero Agregarla");
                }
            }       
        });        
    });     
    
     $("#txtIdentificacion").change(function(){     
    var parametros = {
        "identificacion" : $('#txtIdentificacion').val(),
        "opcion":2
    };      
    $.ajax({      
            url:   '../Controlador/ctrlGiro.php',
            data:  parametros,
            type:  'post',                
            success:  function (response) {   
                if(response != ""){
                    $("#Mensaje").html("Ya existe persona " + response);
                    $("#txtNombres").val(response);
                    $('#txtIdentificacion').focus();
                }else{
                    $("#Mensaje").html("");
                }                
            }       
        });        
    });     
});


 

