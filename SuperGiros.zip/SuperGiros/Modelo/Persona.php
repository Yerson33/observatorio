<?php
/**
 * Description of Persona
 *
 * @author CesarCuellar
 */
class Persona {
    //put your code here
    private $identificacion;
    private $nombres;
    private $apellidos;
    private $direccion;
    private $telefono;
    private $correo;
    
    /**
     * Constructor de la Clase Persona
     * @param type $identificacion
     * @param type $nombres
     * @param type $apellidos
     * @param type $direccion
     * @param type $telefono
     * @param type $correo
     */
    public function __construct($identificacion=null,$nombres=null,
    $apellidos=null,$direccion=null,$telefono=null,$correo=null) {
        
        $this->identificacion=$identificacion;
        $this->nombres=$nombres;
        $this->apellidos=$apellidos;
        $this->direccion=$direccion;
        $this->telefono=$telefono;
        $this->correo=$correo;        
    }
    public function getIdentificacion() {
        return $this->identificacion;
    }

    public function getNombres() {
        return $this->nombres;
    }

    public function getApellidos() {
        return $this->apellidos;
    }

    public function getDireccion() {
        return $this->direccion;
    }

    public function getTelefono() {
        return $this->telefono;
    }

    public function getCorreo() {
        return $this->correo;
    }

    public function setIdentificacion($identificacion) {
        $this->identificacion = $identificacion;
    }

    public function setNombres($nombres) {
        $this->nombres = $nombres;
    }

    public function setApellidos($apellidos) {
        $this->apellidos = $apellidos;
    }

    public function setDireccion($direccion) {
        $this->direccion = $direccion;
    }

    public function setTelefono($telefono) {
        $this->telefono = $telefono;
    }

    public function setCorreo($correo) {
        $this->correo = $correo;
    }


}
