<?php
/**
 * Description of Giro
 * 
 * @author CesarCuellar
 */
class Giro {
    //put your code here
    private $remitente;
    private $destinatario;
    private $valor;
    private $fecha;
    
    /**
     * Constructor Clase Giro
     * @param Persona $remitente, Persona que envía el dinero
     * @param Persona $destinatario, Persona a la que se le envía el giro
     * @param int $valor, valor del giro
     * @param date $fecha, Fecha en la que se realiza el giro
     */
    public function __construct(Persona $remitente = null,
      Persona $destinatario=null, $valor=null,$fecha=null) {        
        $this->remitente=$remitente;
        $this->destinatario=$destinatario;
        $this->valor=$valor;
        $this->fecha=date('Y-m-d');        
    }
    
    public function getRemitente() {
        return $this->remitente;
    }

    public function getDestinatario() {
        return $this->destinatario;
    }

    public function getValor() {
        return $this->valor;
    }

    public function getFecha() {
        return $this->fecha;
    }

    public function setRemitente($remitente) {
        $this->remitente = $remitente;
    }

    public function setDestinatario($destinatario) {
        $this->destinatario = $destinatario;
    }

    public function setValor($valor) {
        $this->valor = $valor;
    }

    public function setFecha($fecha) {
        $this->fecha = $fecha;
    }



}
