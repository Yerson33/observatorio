<?php

/**
 * Description of DatosGiro
 *
 * @author CesarCuellar
 */
class DatosGiro {
    //put your code here
    private $nombreArchivoPersonas;
    private $nombreArchivoGiros;
    private $error;
    
    public function __construct($nombreArchivoP=null, $nombreArchivoG=null) {
        $this->nombreArchivoPersonas=$nombreArchivoP;
        $this->nombreArchivoGiros=$nombreArchivoG;
        $this->crearArchivoGiros();
        $this->crearArchivoPersonas();
    }
    
    public function getNombreArchivoPersonas() {
        return $this->nombreArchivoPersonas;
    }

    public function getNombreArchivoGiros() {
        return $this->nombreArchivoGiros;
    }

    public function getError() {
        return $this->error;
    }

    public function crearArchivoPersonas(){
        $encabezado = array('Identificación','Nombres', 'Apellidos',
            'Direccion', 'Teléfono','Correo');
        if (!file_exists($this->nombreArchivoPersonas)){
            $archivo = fopen($this->nombreArchivoPersonas, "w");
            fputcsv($archivo, $encabezado,";");
            fclose($archivo);
        }
    }
    
    public function crearArchivoGiros(){
        $encabezado = array('Remitente','Destinatario','Valor','Fecha');
        if (!file_exists($this->nombreArchivoGiros)){
            $archivo = fopen($this->nombreArchivoGiros, "w");
            fputcsv($archivo, $encabezado,";");
            fclose($archivo);
        }
    }
    /**
     * Agrega el giro al archivo de Giros
     * @param Giro $unGiro, objeto con todos los datos del giro
     * @return boolean, true si se realizó o false lo contrario
     */
    public function agregarGiro(Giro $unGiro){
        try{
            $datosGiro=array();
            $datosGiro[]=$unGiro->getRemitente()->getIdentificacion();
            $datosGiro[]=$unGiro->getDestinatario()->getIdentificacion();
            $datosGiro[]=$unGiro->getValor();
            $datosGiro[]=$unGiro->getFecha();
            $archivo = fopen($this->nombreArchivoGiros, "a+");
            fputcsv($archivo, $datosGiro,";");
            fclose($archivo);  
            return true;
        } catch (Exception $ex) {
            $this->error=$ex->getMessage();
            return false;
        }
    }
    
    /**
     * Agregar persona al archivo de Personas
     * @param Persona $persona, incluye todos los atributos de una persona
     * @return boolean, true si se agregó al archivo de lo contrario false
     */
    public function agregarPersona(Persona $persona){
        try{
            $datosPersona = array();
            $datosPersona[]=$persona->getIdentificacion();
            $datosPersona[]=$persona->getNombres();
            $datosPersona[]=$persona->getApellidos();
            $datosPersona[]=$persona->getDireccion();
            $datosPersona[]=$persona->getTelefono();
            $datosPersona[]=$persona->getCorreo();
            $archivo = fopen($this->nombreArchivoPersonas, "a+");
            fputcsv($archivo, $datosPersona,";");
            fclose($archivo);  
            return true;
        }catch(Exception $ex){
            $this->error=$ex->getMessage();
            return false;
        }        
        
    }
    /**
     * Obtiene los datos de una persona de acuerdo a una identificación
     * @param type $identificacion identificación del cliente
     * @return boolean|\Persona
     */
     public function obtenerPersonaByIdentificacion($identificacion){
        try{
            $this->error="";
            $archivo = fopen($this->nombreArchivoPersonas,"r");
            $fila=0;
            $persona = null;
            while($registroPersona = fgetcsv($archivo,1000,";")){
                if ($fila>0){
                    if($registroPersona[0]==$identificacion){
                      $persona=new Persona();
                      $persona->setIdentificacion($registroPersona[0]);
                      $persona->setNombres($registroPersona[1]);
                      $persona->setApellidos($registroPersona[2]);
                      $persona->setDireccion($registroPersona[3]);
                      $persona->setTelefono($registroPersona[4]);
                      $persona->setCorreo($registroPersona[5]);
                      break;                  
                    }
                }   
                $fila++;
            }
            fclose($archivo);
            return $persona;
        } catch (Exception $ex) {
            $this->error=$ex->getMessage();
            return false; 
        }
    }

    /**
     * Devuelve los giros que se encuentran en el archivo Giros.csv
     * @return boolean|\Giro
     */
    public function listarGiros(){
        $datosGiros = array();
        try{
            $this->error="";
            $archivo = fopen($this->nombreArchivoGiros,"r");
            $fila=0;                     
            while($registroGiro = fgetcsv($archivo,1000,";")){
                if ($fila>0){                    
                    $identificacionRemitente=$registroGiro[0];
                    $remitente = $this->obtenerPersonaByIdentificacion($identificacionRemitente);                  
                    $identificacionDestinatario=$registroGiro[1];
                    $destinatario = $this->obtenerPersonaByIdentificacion($identificacionDestinatario);
                    $valor= $registroGiro[2];
                    $fecha = $registroGiro[3];
                    $unGiro = new Giro();
                    $unGiro->setRemitente($remitente);
                    $unGiro->setDestinatario($destinatario);
                    $unGiro->setValor($valor);
                    $unGiro->setFecha($fecha);                    
                    $datosGiros[]=$unGiro; //agregar el giro al arreglo
                }   
                $fila++;
            }
            fclose($archivo);
            return $datosGiros;
        } catch (Exception $ex) {
            $this->error=$ex->getMessage();
            return false; 
        }
        
    }
    /**
     * Obtiene la lista de las personas almacenadas en el archivo Personas.csv
     * @return boolean|\Persona
     */
    public function listarPersonas(){
        $listaPersonas=array();
        try{
            $this->error="";
            $archivo = fopen($this->nombreArchivoPersonas,"r");
            $fila=0;                     
            while($registroPersona = fgetcsv($archivo,1000,";")){
                if ($fila>0){                    
                    $unaPersona=new Persona();
                    $unaPersona->setIdentificacion($registroPersona[0]);
                    $unaPersona->setNombres($registroPersona[1]);
                    $unaPersona->setApellidos($registroPersona[2]);
                    $unaPersona->setDireccion($registroPersona[3]);
                    $unaPersona->setTelefono($registroPersona[4]);
                    $unaPersona->setCorreo($registroPersona[5]);                   
                    $listaPersonas[]=$unaPersona; //agregar persona a la lista
                }   
                $fila++;
            }
            fclose($archivo);
            return $listaPersonas;
        } catch (Exception $ex) {
            $this->error=$ex->getMessage();
            return false; 
        }
    }
}
