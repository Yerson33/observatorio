<?php
session_start();
extract($_REQUEST);
if(!isset($_GET['pg'])){
    $pg="contenido";
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="../Css/footer.css" rel="stylesheet" type="text/css"/>
<link href="../Css/form.css" rel="stylesheet" type="text/css"/>
<link href="../Css/header.css" rel="stylesheet" type="text/css"/>
<link href="../Css/index.css" rel="stylesheet" type="text/css"/>
<link href="../Css/nav.css" rel="stylesheet" type="text/css"/>
<link href="../Css/template.css" rel="stylesheet" type="text/css"/>
<script src="../Recursos/jquery/external/jquery/jquery.js" type="text/javascript"></script>
<script src="../Recursos/jquery/jquery-ui.js" type="text/javascript"></script>
<link href="../Recursos/jquery/jquery-ui.css" rel="stylesheet" type="text/css"/>
<script src="../Recursos/jquery/jquery-ui.min.js" type="text/javascript"></script>
<script src="../Js/ajax.js" type="text/javascript"></script>
<title>SISTEMA DE GIROS SUPERGIROS ADSI 1094253</title>
</head>
<body>
    <div id="Contenedor">
        <header class="principal"><?php include "encabezado.php"?> </header>
        <nav class="principal"> <?php include "menu.php"?> </nav>
        <section class="principal"><?php include $pg.".php"?> </section>
        <footer class="principal"><?php include "piePagina.php"?> </footer>
    </div>
</body>
</html>