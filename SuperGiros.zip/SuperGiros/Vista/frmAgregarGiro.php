<?php
extract ($_REQUEST);
if (!isset($_SESSION['usuario'])){
    header("location:index.php?pg=frmIniciarSesion&x=2");
}
?>
<p>
<form name="form1" method="post" action="../Controlador/ctrlGiro.php">
<input type="hidden" name="opcion" value="1">
  <table width="40%" border="0" align="center">
    <tr>
      <td colspan="2" align="center">AGREGAR GIRO</td>
    </tr>
    <tr>
      <td width="20%">Id. Remitente:</td>
      <td width="20%"><input type="number" name="txtIdentificacionRemitente" 
         id="txtIdentificacionRemitente" required placeholder="Documento Remitente">
          <div id="MensajeRemitente"></div>
      </td>
    </tr>
    <tr>
      <td>Id. Destinatario:</td>
      <td><input type="number" name="txtIdentificacionDestinatario" 
          id="txtIdentificacionDestinatario" required placeholder="Documento Destinatario">
          <div id="MensajeDestinatario"></div>
      </td>
        
    </tr>
    <tr>
      <td>Valor:</td>
      <td><label for="textfield"></label>
      <input type="number" name="valor" id="valor" required placeholder="Valor a Girar"></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><input type="submit" name="button" id="button" value="Enviar"></td>
    </tr>
  </table>
</form>
<br>
<p style=" text-align: center">
<?php
    if (@$x==1)
        echo "Giro Agregado Correctamente";
    if (@$x==2)
        echo "No se pudo agregar el Giro";
?>
</p>