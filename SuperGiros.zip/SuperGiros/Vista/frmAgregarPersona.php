<?php
extract ($_REQUEST);
if (!isset($_SESSION['usuario'])){
    header("location:index.php?pg=frmIniciarSesion&x=2");
}
?>
<p>
<form name="form1" method="post" action="../Controlador/ctrlPersona.php">
    <input name="opcion" type="hidden" id="opcion" value="1">
  <table width="25%" border="0" align="center">
    <tr>
        <td align="center" width="100%">AGREGAR CLIENTE</td>
    </tr>
    <tr>
      <td><Label>Ingrese su Identificación:</Label>        
          <input name="txtIdentificacion" type="number" id="txtIdentificacion" size="50" required>
          <div id="Mensaje"></div>
      </td>
    </tr>
    <tr>
      <td><Label>Ingrese su  Nombre:</Label> 
      <input name="txtNombres" type="text" id="txtNombres" size="50" required></td>
    </tr>
    <tr>
      <td><Label>Ingrese sus Apellidos:</Label> 
      <input name="txtApellidos" type="text" id="txtApellidos"  size="50" required></td>
    </tr>
    <tr>
      <td> <Label>Ingrese Dirección:</Label>
      <input name="txtDireccion" type="text" id="txtDireccion"  size="50" required></td>
    </tr>
    <tr>
      <td><Label>Ingrese Telefono:</Label>
      <input name="txtTelefono" type="number" id="txtTelefono"  size="50" required></td>
    </tr>
    <tr>
      <td><p><Label>Correo Electrónico   </Label>   
        <input name="txtCorreo" type="email" id="txtCorreo"  size="50" required>
      </p></td>
    </tr>
    <tr>
        <td align="center" ><input type="submit" name="button" id="button" value="Enviar"></td>
    </tr>
  </table>
</form>
<p align="center">
    <?php 
    if(@$x==1)
        echo "Persona Agregada Correctamente";
     if(@$x==2)
        echo "Problemas no se pudo Agregar la Persona";
    ?>
    
</p>
