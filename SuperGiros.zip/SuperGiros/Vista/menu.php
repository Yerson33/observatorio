    <ul>
    <li><a href="#">Clientes</a>
        <ul class='submenu'>
            <li><a href="index.php?pg=frmAgregarPersona">Agregar Cliente</a></li>            
            <li><a href="index.php?pg=listarPersonas">Listar</a></li>              
        </ul>    
    </li>
    <li><a href="#">Giros</a>
        <ul class='submenu'>
            <li><a href="index.php?pg=frmAgregarGiro">Envío de Giros</a></li>           
            <li><a href="index.php?pg=listarGiros">Listar Giros</a></li>              
        </ul>    
    </li>        
   <li><a href="salir.php">Salir</a>
   	
   </li>
   
   <em class="usuario"><?php echo "Usuario:". $_SESSION['usuario']?></em>
   <div class="foto"></div>
  
   
    