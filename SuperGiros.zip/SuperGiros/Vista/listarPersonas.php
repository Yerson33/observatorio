<?php
extract ($_REQUEST);
if (!isset($_SESSION['usuario'])){
    header("location:index.php?pg=frmIniciarSesion&x=2");
}
include "../Modelo/Persona.php";
include "../Modelo/DatosGiro.php";
$nombreArchivoPersonas="../Controlador/Personas.csv";
$nombreArchivoGiros="../Controlador/Giros.csv";
$objDatosGiro = new DatosGiro($nombreArchivoPersonas,$nombreArchivoGiros);
$listaPersonas = $objDatosGiro->listarPersonas();
$cantidad = count($listaPersonas);
?>
<h2 align="center"><strong>LISTADO DE CLIENTES</strong></h2>
<table width="70%" border="0" align="center">
  <tr  bgcolor="#CCCCFF">
    <td width="10%" align="center" >Identificacion</td>
    <td width="20%" align="center" >Nombres</td>
    <td width="20%" align="center">Apellidos</td>
    <td width="30%" align="center">Dirección</td>
    <td width="10%" align="center">Teléfono</td>
    <td width="20%" align="center">Correo</td>
  </tr>
  <?php
  for($index=0;$index<$cantidad;$index++)
  { ?>  
    <tr>    
        <td align="left"><?php echo $listaPersonas[$index]->getIdentificacion()?>  </td>
        <td align="left"><?php echo $listaPersonas[$index]->getNombres()?></td>
        <td align="left"><?php echo $listaPersonas[$index]->getApellidos()?></td>
        <td align="left"><?php echo $listaPersonas[$index]->getDireccion()?></td>
        <td align="right"><?php echo $listaPersonas[$index]->getTelefono()?></td>
        <td align="left"><?php echo $listaPersonas[$index]->getCorreo()?></td>  
         
    </tr>
  <?php        
    } //Cerrar el For
  ?>
</table>
<br><br>