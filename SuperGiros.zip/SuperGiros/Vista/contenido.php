<?php
//if (!isset($_SESSION['usuario'])){
  //  header("location:index.php?pg=frmIniciarSesion&x=2");
//}
?>
<p><h2 align="center">Bienvenidos a Nuestro Sistema de Envío de Giros</h2></p>
<h3>Las tareas disponibles son:</h3>
<ul>
  <p> - Agregar Clientes</p>
  <p> - Listar Clientes</p>
  <p> - Registro de Giros</p>
  <p> - Listar Giros</p>
</ul>
