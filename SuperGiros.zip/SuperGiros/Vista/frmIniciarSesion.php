<?php
extract ($_REQUEST);
?>
<br> 
<form name="form1" method="post" action="../Controlador/ctrlIniciarSesion.php">
  <table width="26%" border="1" align="center">
    <tr>
      <td align="center">INICIÓ DE SESIÓN</td>
    </tr>
    <tr>
      <td><label for="txtUsuario"> Ingrese Usuario:</label>
      <input name="txtUsuario" type="text" id="txtUsuario" size="50"></td>
    </tr>
    <tr>
      <td><label for="txtPassword">Ingrese su Password</label>
      <input name="txtPassword" type="password" id="txtPassword" size="50"></td>
    </tr>
    <tr>
      <td align="center"><input type="submit" name="button" id="button" value="Enviar"></td>
    </tr>
  </table>
</form>
<br>
<p style="text-align: center">
    <?php
        if (@$x==1){
            echo "Usuario no reconocido";
        }
        if (@$x==2){
            echo "Para ingresar debe iniciar sesión";
        }
        if (@$x==3){
            echo "Ha cerrado la sesión......";
        }
    ?>
</p>
