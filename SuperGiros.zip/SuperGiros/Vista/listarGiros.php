<?php
extract ($_REQUEST);
if (!isset($_SESSION['usuario'])){
    header("location:index.php?pg=frmIniciarSesion&x=2");
}
include "../Modelo/Persona.php";
include "../Modelo/Giro.php";
include "../Modelo/DatosGiro.php";
$nombreArchivoPersonas="../Controlador/Personas.csv";
$nombreArchivoGiros="../Controlador/Giros.csv";
$objDatosGiro = new DatosGiro($nombreArchivoPersonas,$nombreArchivoGiros);
$listaGiros = $objDatosGiro->listarGiros();
$cantidad = count($listaGiros);
?>
<h2 align="center"><strong>LISTADO DE GIROS</strong></h2>
<table width="50%" border="0" align="center">
  <tr  bgcolor="#CCCCFF">
    <td width="30%" align="center" >Remitente</td>
    <td width="30%" align="center" >Destinatario</td>
    <td width="20%" align="center">Valor</td>
    <td width="20%" align="center">Fecha</td>
  </tr>
  <?php  
  for($index=0;$index<$cantidad;$index++)
  {?>  
    <tr>
        <td align="left"><?php echo $listaGiros[$index]->getRemitente()->getNombres().' '.
          $listaGiros[$index]->getRemitente()->getApellidos()?> </td>
        <td align="left"><?php echo $listaGiros[$index]->getDestinatario()->getNombres().' '.
          $listaGiros[$index]->getDestinatario()->getApellidos()?>  </td>
        <td align="right"><?php echo "$ ".$listaGiros[$index]->getValor()?></td>
        <td align="center"><?php echo $listaGiros[$index]->getFecha()?></td>
         
    </tr>
  <?php    
    } //cerrar el For
  ?>
</table>
<br><br>