<?php
extract($_REQUEST);
include "../Modelo/Persona.php";
include "../Modelo/Giro.php";
include "../Modelo/DatosGiro.php";
$nombreArchivoPersonas="Personas.csv";
$nombreArchivoGiros="Giros.csv";
//lo que viene del formulario
$objDatosGiro = new DatosGiro($nombreArchivoPersonas,$nombreArchivoGiros);
switch($opcion){
    case 1: //agregarGiro
        $remitente = new Persona($txtIdentificacionRemitente);
        $destinatario = new Persona($txtIdentificacionDestinatario);
        $unGiro = new Giro($remitente,$destinatario,$valor);        
        $giroAgregado = $objDatosGiro->agregarGiro($unGiro);
        if($giroAgregado){
            header("location:../Vista/index.php?pg=frmAgregarGiro&x=1");          
        }
        else{
            header("location:../Vista/index.php?pg=frmAgregarGiro&x=2");  
        }
    break;
    case 2: //buscarCliente               
        $unaPersona=$objDatosGiro->obtenerPersonaByIdentificacion($identificacion);
        if($unaPersona!=null){
            echo $unaPersona->getNombres().' '.$unaPersona->getApellidos();
        }else{
            echo "";
        }
        break;        
    
}
