<?php
extract($_REQUEST);
include "../Modelo/Persona.php";
include "../Modelo/DatosGiro.php";
/*$txtIdentificacion=11;
$txtNombres="María";
$txtApellidos="Madrugada";
$txtDireccion="Calle 9";
$txtTelefono="122222";
$txtCorreo="mmadrugada@hotmail.com";*/
$nombreArchivoPersonas="Personas.csv";
$nombreArchivoGiros="Giros.csv";
switch($_POST['opcion']){
    case 1: //agregar la Persona
        $unaPersona = new Persona($txtIdentificacion,$txtNombres,
                $txtApellidos, $txtDireccion, $txtTelefono, $txtCorreo);
        $objDatosGiro=new DatosGiro($nombreArchivoPersonas, $nombreArchivoGiros);
        $personaAgregada=$objDatosGiro->agregarPersona($unaPersona);
        if ($personaAgregada){
           header("location:../Vista/index.php?pg=frmAgregarPersona&x=1");
        }else{
            header("location:../Vista/index.php?pg=frmAgregarPersona&x=2");
        }        
    break;
}
