<?php
session_start();
extract($_REQUEST);
if (($_REQUEST['txtUsuario']=="Adsi") && ($_REQUEST['txtPassword']=="2017")){
    $_SESSION['usuario']="Pedro Picapiedra";
    header("location:../Vista/index.php?pg=contenido");
}else{
    header("location:../Vista/index.php?pg=frmIniciarSesion&x=1");
}

